def more_source_shout():
    return "Oh my God! We go, we go!"

if __name__ == "__main__":
    print(more_source_shout())