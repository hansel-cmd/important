def sub_source_shout():
    return "Yoaaw! Next sub level!"

if __name__ == "__main__":
    print(sub_source_shout())