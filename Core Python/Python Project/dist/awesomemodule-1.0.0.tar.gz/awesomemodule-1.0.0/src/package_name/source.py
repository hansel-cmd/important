def source_shout():
    return "Oh my! oh my! Hello World, Naevis!"

if __name__ == "__main__":
    print(source_shout())